# Suzume — Setup Guide

## Yeh app kya karti hai
- Mic button dabao → bolo → app command samajh kar action leti hai
- "Call [naam]" bolne par contact list se number dhundh kar seedha call kar deti hai
- "Open [app naam]" bolne par installed app open kar deti hai
- SMS ka structure ready hai (aap message body add kar sakte ho)

## Setup Steps

1. **Android Studio install karo** (agar nahi hai): https://developer.android.com/studio
2. Is poore `JarvisAssistant` folder ko **Open** karo Android Studio mein
   (File → Open → is folder ko select karo)
3. Gradle sync hone do (pehli baar thoda time lagega)
4. Apna phone USB se connect karo, ya ek Emulator banao
5. Phone mein **Developer Options → USB Debugging** ON karo
6. Green ▶ Run button dabao — app phone mein install ho jayegi

## Permissions
Pehli baar app kholte hi yeh permissions maangegi — sab **Allow** karna:
- Microphone (voice sunne ke liye)
- Call Phone
- Contacts
- SMS

## Important limitations (sach batata hoon)
1. Yeh **on-device fixed keyword matching** use kar raha hai ("call", "open" jaise words dhundta hai). Free-form natural conversation (jaisa real JARVIS karta hai) ke liye aapko `handleCommand()` function ko ek AI API (Claude) se connect karna hoga, jisse voice text ko structured action mein convert kiya jaye.
2. **"Hey Jarvis" jaisa always-listening wake word** is version mein nahi hai — abhi button dabana padega. Wake-word ke liye background service + foreground notification chahiye hoga, jo battery aur Android background restrictions ki wajah se zyada complex hai.
3. Kuch phones (Xiaomi, Oppo, Vivo) mein **background permissions** manually enable karni padti hain Settings mein, warna app kaam nahi karegi.
4. Ismein koi AI backend connected nahi hai abhi — yeh sirf keyword-based hai. Agar aap chahen to main next step mein isse Claude API se connect kar sakta hoon taaki yeh smart samjhe.

## Next steps (agar aage badhana ho)
- [ ] Wake word detection add karna ("Hey Jarvis")
- [ ] AI API (Claude) connect karna better command understanding ke liye
- [ ] WhatsApp message bhejna, alarm set karna, jaisi cheezein add karna
- [ ] Background service taaki app band hone par bhi sune

Koi bhi step mein atko to bata dena, main madad karunga.
